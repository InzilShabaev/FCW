#!/usr/bin/python
# -*- coding: utf-8 -*-

# Импорт функций 
import numpy as np
import io
import torch
import torchvision
import torchvision.transforms as T
import matplotlib
import matplotlib.pyplot as plt
import cv2
import os
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor
from flask import *
from werkzeug.utils import secure_filename 

# Объявление переменных
UPLOAD_FOLDER = './uploads'
ALLOWED_EXTENSIONS = {'jpg'}
 
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Обработка файла по созданной модели
def get_plot(name):
	# Подключаем cuda
	device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')

	defect_names = {
	0: "Missing Hole",
	1: "Mouse Bite",
	2: "Open Circuit",
	3: "Short",
	4: "Spur",
	5: "Spurious Copper"
	}
	# Загрузка модели
	model = torchvision.models.detection.fasterrcnn_resnet50_fpn(pretrained=False, num_classes=6)
	in_features = model.roi_heads.box_predictor.cls_score.in_features
	model.roi_heads.box_predictor = FastRCNNPredictor(in_features, num_classes=6)
	model.load_state_dict(torch.load('./model/pcbdetection.pt'))
	model.eval()
	model.to(device)

	# Загрузка изображения
	image_path = './uploads/'+name
	image = cv2.imread(image_path)
	image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
	image = image / 255.0

	# Определение обработчика изображения
	transform = T.Compose([T.ToTensor()])

	# Преобразование изображения
	image = transform(image).to(device)

	# Прогнозирование ограничивающих рамок и меток  изображения
	image = image.float()
	outputs = model([image])
	boxes = outputs[0]['boxes'].detach().cpu().numpy()
	labels = outputs[0]['labels'].detach().cpu().numpy()

	# Визуализация
	fig, ax = plt.subplots(figsize=(12, 8))
	ax.imshow(image.permute(1, 2, 0).cpu().numpy())
	for box, label in zip(boxes, labels):
	    x1, y1, x2, y2 = box
	    w, h = x2 - x1, y2 - y1
	    rect = matplotlib.patches.Rectangle((x1, y1), w, h, linewidth=2, edgecolor='r', facecolor='none')
	    ax.add_patch(rect)
	    ax.text(x1, y2 + 70, defect_names[label], fontsize=8, color='g', backgroundcolor='w')
	os.remove(image_path)
	return plt 

# Главная страница
@app.get('/') 
def single_converter():

    return render_template("upload_form.html") 
 

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/success', methods = ['POST']) 
def success(): 
    if request.method == 'POST': 
        f = request.files['file'] 
        if f and allowed_file(f.filename):
            filename = secure_filename(f.filename)
            f.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        else:
            return render_template("upload_error.html")

	# отправка изображения в функцию
    plot = get_plot(filename) 

	# Сохранение изображения в файл
    plot.savefig(os.path.join('static', 'images', 'plot.png'), dpi=75)
  
    return render_template("matplotlib-plot.html")

# Основная функция
if __name__ == '__main__': 
	# Запуск приложения с отладкой
	app.run(debug=True) 

